export default function loadCourses(course) {
    return {type: "INITIATE", course};
  }