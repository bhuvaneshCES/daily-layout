export default {
    courses: [],
  };
  