import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './components/App';
import loadCourses from './actions/courseActions';
import {Provider} from 'react-redux';
import configureStore from './store/configureStore';

const store = configureStore();
store.dispatch(loadCourses());

ReactDOM.render(
<Provider store={store}>
    <App />
</Provider>
, document.getElementById('root'));
