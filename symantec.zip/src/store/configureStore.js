import {createStore} from 'redux';
import courseReducer from '.././reducers/courseReducers';

export default function configureStore(initialState) {
  return createStore(
    courseReducer,
    initialState
  );
}